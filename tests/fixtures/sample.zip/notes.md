# notes

in a zip
